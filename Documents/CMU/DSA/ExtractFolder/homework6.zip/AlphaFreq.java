import java.util.Comparator;

public class AlphaFreq implements Comparator<Word> {

}
