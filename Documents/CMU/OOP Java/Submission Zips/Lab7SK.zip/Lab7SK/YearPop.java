public class YearPop {
    private int year;
    private double pop;

    public YearPop(int year, double pop) {
        this.year = year;
        this.pop = pop;
    }

    public int getYear() {
        return year;
    }

    public double getPop() {
        return pop;
    }
}
