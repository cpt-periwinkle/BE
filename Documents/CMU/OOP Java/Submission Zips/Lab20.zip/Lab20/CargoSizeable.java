public interface CargoSizeable {
    public int getLength();
    public int getWidth();
    public String getContents();
}
